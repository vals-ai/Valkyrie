# ok-pi-agent

Private, pinned Pi agent profile for unattended Valkyrie execution.

Phase A implements the local ValSmith MVP source and non-secret verification only. This directory is not yet initialized or published as a Git repository, and no live Valkyrie run has been authorized.

## Runtime contract

- Valkyrie installs the bundle with `bash /bundle/ok-pi-agent/setup.sh`.
- Valkyrie executes `/usr/local/bin/python3 /bundle/ok-pi-agent/run_agent.py` from the benchmark workspace.
- ValSmith supplies the fixed problem path `/workspace/problem_statement.md`.
- Valkyrie substitutes task identity into `--task-id`; the bridge maps it to its internal `TASK_ID` invariant.
- The default unattended deadline is 7,200 seconds.
- ValSmith owns workspace diff capture and evaluation; the bridge does not produce a Vals-format result.

The raw `{problem_statement_path}` replacement is safe only for the ValSmith-owned fixed path above. Other benchmark providers require a separately reviewed contract.

## Architecture

1. `setup.sh` verifies the anchored profile manifest and vendored source hashes, downloads and verifies Node 26.4.0, installs the exact npm lock, and installs hash-locked Docent into the bundle-local Python tools environment.
2. `run_agent.py` creates an isolated mode-`0700` Pi agent directory and links only curated profile resources.
3. The bridge decodes the runtime Codex auth secret into mode-`0600` `auth.json`, removes the base64 environment value from the Pi child, and launches the pinned Pi 0.80.6 entrypoint in RPC mode.
4. Pi starts with project `.pi` resources disabled and a closed startup tool allowlist.
5. The bridge requires an atomic startup tool-surface attestation, cancels dialog UI requests, waits for `agent_settled`, requires an atomic terminal goal-state file, redacts all observability artifacts, and terminates the complete process group even if Pi exits first.

The profile preserves the current model (`openai-codex/gpt-5.6-sol`), max thinking, priority service tier, retries, coding rules, code intelligence, context handling, and unrestricted `pi-web-access`. Personal memory, human interaction, orchestration, private/OAuth MCP, desktop, and image/UI surfaces are excluded.

## Runtime secret

The contract maps:

```text
PI_CODEX_AUTH_JSON_B64 -> ok-pi-agent-codex-auth-json-b64
```

The secret value is the complete Codex `auth.json` encoded as base64. Valkyrie may override the AWS Secrets Manager reference at run creation. Secret access and a live run are Phase C operations and are not part of Phase A.

## Output

The bridge writes under `/logs/ok-pi-agent`:

- `trajectory.jsonl`
- `raw_output.txt`
- `stderr.txt`
- `final_message.txt`
- `summary.json`
- `metrics.json`
- `goal-state.json`
- `tool-state.json`
- `compactions/`

Valkyrie archives existing output and continues evaluation for exits `0`, `124`, and `137`. Bridge exits `20`–`23` are task errors and do not reach final-output archive handling.

## Exit codes

| Code | Meaning |
|---:|---|
| 0 | Settled complete or settled concrete task blocker |
| 20 | Missing or invalid auth secret |
| 21 | Pinned profile, startup, or handshake failure |
| 22 | RPC protocol, prompt, or terminal-state failure |
| 23 | Unexpected Pi process exit |
| 124 | Bridge deadline or termination signal after process-group cleanup |

## Local verification

No command below reads credentials or invokes a model.

```bash
XDG_CACHE_HOME=$PWD/.scratch/cache UV_CACHE_DIR=$PWD/.scratch/cache/uv uv run pytest -q
uv run ruff format --check run_agent.py tests
uv run basedpyright run_agent.py tests
shellcheck setup.sh
npm --prefix profile run check
uv run python -m scripts.verify_profile profile
uv run python -m scripts.check_profile_rpc
```

The profile startup check invokes pinned Pi RPC, calls `get_state`, and exits without submitting a prompt.

## Security boundary

Accepted private-v1 risks:

- Pi and tool subprocesses share a UID and can read runtime `auth.json`.
- Unrestricted outbound access preserves current web behavior and increases credential-exfiltration impact for a compromised task or tool.
- Repository `AGENTS.md`/`CLAUDE.md` files are untrusted prompt input; the startup and runtime tool gates remain authoritative.

## Deferred phases

- **Phase B:** Git initialization, private repository creation, commit, and publication require separate approval.
- **Phase C:** agent push and exactly one live ValSmith task require separate approval plus the concrete Valkyrie target, dataset, task ID, and AWS secret reference.
- SWE-bench and Terminal-Bench are not part of v1.
