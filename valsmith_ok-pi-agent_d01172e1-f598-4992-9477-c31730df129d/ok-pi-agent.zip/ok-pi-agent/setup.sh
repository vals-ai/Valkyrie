#!/usr/bin/env bash
set -euo pipefail

ROOT=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
PROFILE="$ROOT/profile"
NODE_VERSION="26.4.0"
PI_VERSION="0.80.6"
NODE_ARCHIVE="node-v${NODE_VERSION}-linux-x64.tar.xz"
NODE_URL="https://nodejs.org/dist/v${NODE_VERSION}/${NODE_ARCHIVE}"
NODE_SHA256="5c4286dcd5bbd5acb1ccc7eb0e088bd5eb1e3affad671ee9364004f8f6a4a431"
SOURCES_LOCK_SHA256="2336aac5356950f18322bec7673252dcd313ef968dde36de0f464cb48644af2f"
VERIFIER_SHA256="bd2a2b94fb0604a3d8e2999d8d164f56405be40465586ef4e1c602be64d00866"
NODE_RUNTIME="$PROFILE/runtime/node-v${NODE_VERSION}-linux-x64"
NODE="$NODE_RUNTIME/bin/node"
PI_ENTRY="$PROFILE/node_modules/@earendil-works/pi-coding-agent/dist/cli.js"

if [[ -x /usr/local/bin/python3 ]]; then
  PYTHON="/usr/local/bin/python3"
elif [[ -x /usr/bin/python3 ]]; then
  PYTHON="/usr/bin/python3"
else
  printf 'Python 3 is required at /usr/local/bin/python3 or /usr/bin/python3\n' >&2
  exit 1
fi

if [[ $(uname -m) != "x86_64" ]]; then
  printf 'Unsupported architecture: %s\n' "$(uname -m)" >&2
  exit 1
fi

for required in package.json package-lock.json settings.json sources.lock.json; do
  if [[ ! -f "$PROFILE/$required" ]]; then
    printf 'Missing pinned profile resource: %s\n' "$required" >&2
    exit 1
  fi
done
if [[ ! -f "$ROOT/scripts/verify_profile.py" ]]; then
  printf 'Missing profile verifier\n' >&2
  exit 1
fi

# Rebuild unverified generated state exclusively from the pinned inputs below.
find "$PROFILE" -depth -type d \( \
  -name node_modules -o \
  -name runtime -o \
  -name python-tools -o \
  -name .pi-lens -o \
  -name .pi-subagents -o \
  -name .pytest_cache -o \
  -name .ruff_cache -o \
  -name .scratch -o \
  -name __pycache__ \
\) -exec rm -rf -- {} +

file_sha256() {
  "$PYTHON" - "$1" <<'PY'
from hashlib import sha256
from pathlib import Path
import sys

print(sha256(Path(sys.argv[1]).read_bytes()).hexdigest())
PY
}

if [[ $(file_sha256 "$PROFILE/sources.lock.json") != "$SOURCES_LOCK_SHA256" ]]; then
  printf 'Profile source manifest checksum mismatch\n' >&2
  exit 1
fi
if [[ $(file_sha256 "$ROOT/scripts/verify_profile.py") != "$VERIFIER_SHA256" ]]; then
  printf 'Profile verifier checksum mismatch\n' >&2
  exit 1
fi
"$PYTHON" "$ROOT/scripts/verify_profile.py" "$PROFILE"

if [[ ! -x "$NODE" ]]; then
  mkdir -p "$PROFILE/runtime"
  archive=$(mktemp "$PROFILE/runtime/.node-download.XXXXXX")
  cleanup_archive() {
    rm -f -- "$archive"
  }
  trap cleanup_archive EXIT

  "$PYTHON" - "$NODE_URL" "$archive" <<'PY'
from pathlib import Path
import sys
from urllib.request import urlopen

url = sys.argv[1]
destination = Path(sys.argv[2])
with urlopen(url, timeout=120) as response, destination.open("wb") as output:
    while chunk := response.read(1024 * 1024):
        output.write(chunk)
PY

  actual_sha=$("$PYTHON" - "$archive" <<'PY'
from hashlib import sha256
from pathlib import Path
import sys

print(sha256(Path(sys.argv[1]).read_bytes()).hexdigest())
PY
)
  if [[ "$actual_sha" != "$NODE_SHA256" ]]; then
    printf 'Node archive checksum mismatch\n' >&2
    exit 1
  fi

  tar -xJf "$archive" -C "$PROFILE/runtime"
  cleanup_archive
  trap - EXIT
fi

if [[ $($NODE --version) != "v${NODE_VERSION}" ]]; then
  printf 'Pinned Node version check failed\n' >&2
  exit 1
fi

export PATH="$NODE_RUNTIME/bin:/usr/local/bin:/usr/bin:/bin"
export npm_config_ignore_scripts=false
npm ci --prefix "$PROFILE"

rm -rf -- "$PROFILE/python-tools"
"$PYTHON" -m venv "$PROFILE/python-tools"
"$PROFILE/python-tools/bin/python" -m pip install \
  --disable-pip-version-check \
  --require-hashes \
  -r "$PROFILE/python-requirements.lock"
if [[ ! -x "$PROFILE/python-tools/bin/docent-mcp" ]]; then
  printf 'Pinned Docent executable is missing\n' >&2
  exit 1
fi

if [[ ! -f "$PI_ENTRY" ]]; then
  printf 'Pinned Pi entrypoint is missing: %s\n' "$PI_ENTRY" >&2
  exit 1
fi

actual_pi_version=$($NODE "$PI_ENTRY" --version)
if [[ "$actual_pi_version" != "$PI_VERSION" ]]; then
  printf 'Pinned Pi version mismatch: expected %s, got %s\n' \
    "$PI_VERSION" "$actual_pi_version" >&2
  exit 1
fi

printf 'Installed ok-pi-agent runtime: Node %s, Pi %s\n' \
  "$NODE_VERSION" "$PI_VERSION"
