import os

print("hello")
