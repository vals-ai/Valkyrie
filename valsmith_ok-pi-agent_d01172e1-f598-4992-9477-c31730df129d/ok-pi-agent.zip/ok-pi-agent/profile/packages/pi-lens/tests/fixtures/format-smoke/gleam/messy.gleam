pub fn main() {
  let x=1
  x
}
