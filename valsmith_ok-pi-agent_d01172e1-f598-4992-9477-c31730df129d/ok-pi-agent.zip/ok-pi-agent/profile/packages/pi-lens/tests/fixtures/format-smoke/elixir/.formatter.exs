[
  inputs: ["*.{ex,exs}"]
]
