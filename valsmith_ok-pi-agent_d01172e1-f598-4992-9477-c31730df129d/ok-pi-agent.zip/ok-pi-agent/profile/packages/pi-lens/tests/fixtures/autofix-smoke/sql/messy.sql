select  a  from  mytable
