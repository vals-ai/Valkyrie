{ outputs = _: {}; }
