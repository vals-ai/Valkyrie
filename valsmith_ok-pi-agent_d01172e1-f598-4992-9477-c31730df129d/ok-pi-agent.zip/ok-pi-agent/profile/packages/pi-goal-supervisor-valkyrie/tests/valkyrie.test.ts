import assert from "node:assert/strict";
import { mkdtempSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { test } from "node:test";
import compactAdvisor from "../../../extensions/compact-advisor.ts";
import { registerGoalSupervisor } from "../src/index.ts";
import { STATE_CUSTOM_TYPE, type GoalJudgeResult, type GoalSupervisorState } from "../src/types.ts";

const allowedTools = ["read", "bash"];

type Judge = (
  state: GoalSupervisorState,
  assistantText: string,
  evidence: string,
  ctx: unknown,
) => GoalJudgeResult;

function harness(
  judge?: Judge,
  tools: { active?: string[]; registered?: string[] } = {},
) {
  const entries: Array<{ type: "custom"; customType: string; data: unknown }> = [];
  const hooks = new Map<
    string,
    Array<(event: unknown, ctx: unknown) => unknown>
  >();
  let handler: ((args: string, ctx: unknown) => Promise<void>) | undefined;
  let activeTools = tools.active ?? ["read"];
  const registeredTools = tools.registered ?? allowedTools;
  const sentMessages: Array<{ message: unknown; options: unknown }> = [];
  let aborts = 0;
  const dir = mkdtempSync(join(tmpdir(), "goal-valkyrie-"));
  const terminalStatePath = join(dir, "goal-state.json");
  const toolStatePath = join(dir, "tool-state.json");
  const api = {
    on(event: string, hook: (event: unknown, ctx: unknown) => unknown) {
      const eventHooks = hooks.get(event) ?? [];
      eventHooks.push(hook);
      hooks.set(event, eventHooks);
    },
    registerCommand(
      _name: string,
      options: { handler: (args: string, ctx: unknown) => Promise<void> },
    ) {
      handler = options.handler;
    },
    appendEntry(customType: string, data: unknown) {
      entries.push({ type: "custom", customType, data });
    },
    sendMessage(message: unknown, options: unknown) {
      sentMessages.push({ message, options });
    },
    getActiveTools: () => activeTools,
    getAllTools: () => registeredTools.map((name) => ({ name })),
    setActiveTools(names: string[]) {
      activeTools = names;
    },
  };
  registerGoalSupervisor(api, {}, {
    allowedTools,
    judge,
    terminalStatePath,
    toolStatePath,
  });
  assert.ok(handler);
  const ctx = {
    sessionManager: {
      getCwd: () => "/tmp/project",
      getSessionId: () => "session-1",
      getBranch: () => entries,
    },
    isIdle: () => true,
    hasPendingMessages: () => false,
    abort: () => {
      aborts += 1;
    },
    ui: { notify() {}, setWidget() {} },
  };
  const state = () =>
    entries.filter((entry) => entry.customType === STATE_CUSTOM_TYPE).at(-1)
      ?.data as GoalSupervisorState | undefined;
  const emit = async (event: string, value: unknown, eventCtx = ctx) => {
    let result: unknown;
    for (const hook of hooks.get(event) ?? []) result = await hook(value, eventCtx);
    return result;
  };
  return {
    api,
    hooks,
    emit,
    handler,
    ctx,
    state,
    activeTools: () => activeTools,
    sentMessages: () => sentMessages,
    aborts: () => aborts,
    terminal: () => JSON.parse(readFileSync(terminalStatePath, "utf8")),
    toolState: () => JSON.parse(readFileSync(toolStatePath, "utf8")),
  };
}

async function startAndDeliver(h: ReturnType<typeof harness>) {
  await h.handler("finish objective", h.ctx);
  const id = h.state()?.pendingContinuation?.id;
  assert.ok(id);
  await h.emit("before_agent_start", { systemPrompt: "base", prompt: id });
}

test("closed allowlist applies before goal mode and blocks unknown tool calls", async () => {
  const h = harness();
  await h.emit("session_start", {});
  assert.deepEqual(h.activeTools(), ["read"]);
  assert.deepEqual(h.toolState(), {
    version: 1,
    allowedTools,
    registeredTools: allowedTools,
    activeTools: ["read"],
  });

  const denied = await h.emit("tool_call", { toolName: "future_unknown" });
  assert.deepEqual(denied, {
    block: true,
    reason: "Tool 'future_unknown' is not enabled by the Valkyrie profile allowlist.",
  });
});

test("startup rejects an allowed tool that is not registered", async () => {
  const h = harness(undefined, { active: ["read"], registered: ["read"] });
  await assert.rejects(
    () => h.emit("session_start", {}),
    /allowed tools are not registered: bash/,
  );
});

test("startup rejects an active tool outside the allowlist", async () => {
  const h = harness(undefined, {
    active: ["read", "future_unknown"],
    registered: ["read", "bash", "future_unknown"],
  });
  await assert.rejects(
    () => h.emit("session_start", {}),
    /active tools are not allowed: future_unknown/,
  );
});

test("inconclusive judge retries exactly three times with unchanged evidence", async () => {
  const calls: Array<{ assistantText: string; evidence: string }> = [];
  const h = harness((_state, assistantText, evidence) => {
    calls.push({ assistantText, evidence });
    return {
      verdict: "inconclusive",
      score: 0,
      reason: "judge unavailable",
      missingEvidence: ["working judge"],
      at: "2026-07-21T00:00:00.000Z",
    };
  });
  await startAndDeliver(h);
  await h.emit("turn_end", {
    message: { role: "assistant", content: "GOAL_DONE: tests passed" },
  });

  assert.equal(calls.length, 3);
  assert.deepEqual(calls, [calls[0], calls[0], calls[0]]);
  assert.equal(h.state()?.status, "blocked");
  assert.equal(h.state()?.counters.judgeAttempts, 3);
  assert.deepEqual(h.terminal(), {
    version: 1,
    goalId: h.state()?.id,
    status: "blocked",
    reasonCode: "judge_inconclusive",
    judgeAttempts: 3,
    timestamp: "2026-07-21T00:00:00.000Z",
  });
});

test("approved completion writes terminal state on the first attempt", async () => {
  const h = harness(() => ({
    verdict: "approved",
    score: 10,
    reason: "complete",
    missingEvidence: [],
    at: "2026-07-21T00:01:00.000Z",
  }));
  await startAndDeliver(h);
  await h.emit("turn_end", {
    message: { role: "assistant", content: "GOAL_DONE: tests passed" },
  });

  assert.equal(h.state()?.status, "complete");
  assert.equal(h.state()?.counters.judgeAttempts, 1);
  assert.equal(h.terminal().status, "complete");
  assert.equal(h.terminal().reasonCode, "approved");
});

async function forceCompactAdvisorFollowUp(h: ReturnType<typeof harness>) {
  compactAdvisor(h.api as Parameters<typeof compactAdvisor>[0]);
  const compactCtx = {
    ...h.ctx,
    isIdle: () => false,
    getContextUsage: () => ({ tokens: 950, contextWindow: 1000 }),
  };
  await h.emit(
    "agent_end",
    { messages: [{ role: "assistant", stopReason: "stop" }] },
    compactCtx,
  );
  await h.emit(
    "session_before_compact",
    {
      preparation: {
        settings: { reserveTokens: 100 },
        tokensBefore: 950,
      },
    },
    compactCtx,
  );
  const sendsBeforeCompact = h.sentMessages().length;
  await h.emit("session_compact", {}, compactCtx);
  assert.equal(h.sentMessages().length, sendsBeforeCompact + 1);
  await h.emit("before_agent_start", {
    systemPrompt: "base",
    prompt: "Auto-compaction completed. Continue the active task.",
  });
  assert.equal(h.aborts(), 1);
  assert.equal(h.sentMessages().length, sendsBeforeCompact + 1);
}

test("compact-advisor follow-up after completion is aborted before another turn", async () => {
  const h = harness(() => ({
    verdict: "approved",
    score: 10,
    reason: "complete",
    missingEvidence: [],
    at: "2026-07-21T00:01:00.000Z",
  }));
  await startAndDeliver(h);
  await h.emit("turn_end", {
    message: { role: "assistant", content: "GOAL_DONE: tests passed" },
  });
  assert.equal(h.state()?.status, "complete");
  await forceCompactAdvisorFollowUp(h);
});

test("compact-advisor follow-up after blocker is aborted before another turn", async () => {
  const h = harness();
  await startAndDeliver(h);
  await h.emit("turn_end", {
    message: {
      role: "assistant",
      content: "GOAL_BLOCKED: automatic command blocker denied deployment",
    },
  });
  assert.equal(h.state()?.status, "blocked");
  await forceCompactAdvisorFollowUp(h);
});

test("declared blocker is terminal and every later prompt is aborted", async () => {
  const h = harness();
  await startAndDeliver(h);
  await h.emit("turn_end", {
    message: {
      role: "assistant",
      content: "GOAL_BLOCKED: automatic command blocker denied deployment",
    },
  });

  assert.equal(h.state()?.status, "blocked");
  assert.equal(h.terminal().reasonCode, "declared_blocker");
  const sends = h.sentMessages().length;
  await h.emit("before_agent_start", {
    systemPrompt: "base",
    prompt: "auto-compaction-continue",
  });
  assert.equal(h.aborts(), 1);
  assert.equal(h.sentMessages().length, sends);
  assert.equal(h.state()?.status, "blocked");
});
