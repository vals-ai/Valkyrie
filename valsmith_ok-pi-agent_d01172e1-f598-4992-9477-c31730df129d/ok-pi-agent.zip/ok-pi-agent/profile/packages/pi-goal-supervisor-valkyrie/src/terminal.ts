import { mkdirSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import type { GoalSupervisorState } from "./types.ts";

export type TerminalGoalState = {
  version: 1;
  goalId: string;
  status: "complete" | "blocked";
  reasonCode: "approved" | "declared_blocker" | "judge_inconclusive";
  judgeAttempts: number;
  timestamp: string;
};

function terminalRecord(state: GoalSupervisorState): TerminalGoalState | undefined {
  if (state.status === "complete") {
    return {
      version: 1,
      goalId: state.id,
      status: "complete",
      reasonCode: "approved",
      judgeAttempts: state.counters.judgeAttempts,
      timestamp: state.updatedAt,
    };
  }
  if (state.status !== "blocked") return undefined;
  return {
    version: 1,
    goalId: state.id,
    status: "blocked",
    reasonCode:
      state.lastBlocker?.source === "judge_error"
        ? "judge_inconclusive"
        : "declared_blocker",
    judgeAttempts: state.counters.judgeAttempts,
    timestamp: state.updatedAt,
  };
}

export function writeTerminalState(
  state: GoalSupervisorState | undefined,
  targetPath: string | undefined,
): void {
  if (!state || !targetPath) return;
  const record = terminalRecord(state);
  if (!record) return;
  mkdirSync(dirname(targetPath), { recursive: true, mode: 0o700 });
  const tempPath = `${targetPath}.${process.pid}.tmp`;
  writeFileSync(tempPath, `${JSON.stringify(record, null, 2)}\n`, {
    encoding: "utf8",
    mode: 0o600,
  });
  renameSync(tempPath, targetPath);
}
