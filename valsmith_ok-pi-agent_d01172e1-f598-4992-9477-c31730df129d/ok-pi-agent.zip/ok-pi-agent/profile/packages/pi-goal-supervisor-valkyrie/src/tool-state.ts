import { mkdirSync, renameSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import type { GoalSupervisorApi } from "./types.ts";

export type ToolStateRecord = {
  version: 1;
  allowedTools: string[];
  registeredTools: string[];
  activeTools: string[];
};

export function attestToolSurface(
  pi: GoalSupervisorApi,
  allowedTools: string[],
  targetPath: string | undefined,
): ToolStateRecord {
  const registeredTools = pi.getAllTools?.().map((tool) => tool.name);
  const activeTools = pi.getActiveTools?.();
  if (!registeredTools || !activeTools)
    throw new Error("Pi tool introspection APIs are required");

  const registered = new Set(registeredTools);
  const allowed = new Set(allowedTools);
  const missing = allowedTools.filter((name) => !registered.has(name));
  if (missing.length > 0)
    throw new Error(`allowed tools are not registered: ${missing.join(", ")}`);
  const unexpected = activeTools.filter((name) => !allowed.has(name));
  if (unexpected.length > 0)
    throw new Error(`active tools are not allowed: ${unexpected.join(", ")}`);

  const record: ToolStateRecord = {
    version: 1,
    allowedTools: [...allowedTools],
    registeredTools: [...registeredTools],
    activeTools: [...activeTools],
  };
  if (!targetPath) return record;

  mkdirSync(dirname(targetPath), { recursive: true, mode: 0o700 });
  const tempPath = `${targetPath}.${process.pid}.tmp`;
  writeFileSync(tempPath, `${JSON.stringify(record, null, 2)}\n`, {
    encoding: "utf8",
    mode: 0o600,
  });
  renameSync(tempPath, targetPath);
  return record;
}
