from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from typing import cast

from run_agent import (
    BridgePaths,
    EFFECTIVE_THINKING_LEVELS,
    MODEL_ID,
    MODEL_PROVIDER,
    PROFILE_LINKS,
    THINKING_LEVEL,
    build_pi_argv,
    load_allowed_tools,
    validate_tool_state,
)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    profile = root / "profile"
    paths = BridgePaths(
        static_profile=profile,
        log_dir=root / ".scratch" / "profile-rpc-logs",
        pi_command=(
            str(profile / "runtime" / "node-v26.4.0-linux-x64" / "bin" / "node"),
            str(
                profile / "node_modules" / "@earendil-works" / "pi-coding-agent" / "dist" / "cli.js"
            ),
        ),
        runtime_parent=root / ".scratch" / "profile-rpc-runtime",
    )
    allowed_tools = load_allowed_tools(profile)
    paths.runtime_parent.mkdir(parents=True, exist_ok=True)
    runtime = Path(tempfile.mkdtemp(prefix="check-", dir=paths.runtime_parent))
    os.chmod(runtime, 0o700)

    try:
        for name in PROFILE_LINKS:
            (runtime / name).symlink_to(profile / name)
        home = runtime / "home"
        home.mkdir(mode=0o700)
        env = {
            "PATH": ":".join(
                [
                    str(profile / "runtime" / "node-v26.4.0-linux-x64" / "bin"),
                    str(profile / "node_modules" / ".bin"),
                    str(profile / "python-tools" / "bin"),
                    "/usr/local/bin",
                    "/usr/bin",
                    "/bin",
                ]
            ),
            "HOME": str(home),
            "PI_CODING_AGENT_DIR": str(runtime),
            "PI_VALKYRIE_GOAL_STATE_PATH": str(runtime / "goal-state.json"),
            "PI_VALKYRIE_TOOL_STATE_PATH": str(runtime / "tool-state.json"),
            "PYTHONSAFEPATH": "1",
            "LANG": "C.UTF-8",
        }
        completed = subprocess.run(
            build_pi_argv(paths, allowed_tools),
            cwd=root,
            env=env,
            input='{"id":"profile-check","type":"get_state"}\n',
            text=True,
            capture_output=True,
            timeout=60,
            check=False,
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"Pi profile check exited {completed.returncode}: {completed.stderr[-2000:]}"
            )

        response: dict[str, object] | None = None
        for line in completed.stdout.splitlines():
            value = cast(object, json.loads(line))
            if not isinstance(value, dict):
                continue
            candidate = cast(dict[str, object], value)
            if candidate.get("type") == "response" and candidate.get("id") == "profile-check":
                response = candidate
                break
        if response is None or response.get("success") is not True:
            raise RuntimeError("Pi profile check did not return a successful get_state response")
        data = response.get("data")
        if not isinstance(data, dict):
            raise RuntimeError("Pi profile check returned invalid state")
        state = cast(dict[str, object], data)
        model = state.get("model")
        if not isinstance(model, dict):
            raise RuntimeError("Pi profile check returned no model")
        model_state = cast(dict[str, object], model)
        if model_state.get("provider") != MODEL_PROVIDER or model_state.get("id") != MODEL_ID:
            raise RuntimeError("Pi profile check loaded the wrong model")
        effective_thinking = state.get("thinkingLevel")
        if effective_thinking not in EFFECTIVE_THINKING_LEVELS:
            raise RuntimeError("Pi profile check loaded the wrong thinking level")
        tool_state = validate_tool_state(runtime / "tool-state.json", allowed_tools)
        raw_active_tools = tool_state["activeTools"]
        if not isinstance(raw_active_tools, list):
            raise RuntimeError("Pi profile check returned invalid active tools")
        active_tools = cast(list[object], raw_active_tools)

        print(
            json.dumps(
                {
                    "piVersion": "0.80.6",
                    "model": f"{MODEL_PROVIDER}/{MODEL_ID}",
                    "requestedThinkingLevel": THINKING_LEVEL,
                    "effectiveThinkingLevel": effective_thinking,
                    "toolAllowlistCount": len(allowed_tools),
                    "activeToolCount": len(active_tools),
                },
                sort_keys=True,
            )
        )
        return 0
    finally:
        shutil.rmtree(runtime, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
